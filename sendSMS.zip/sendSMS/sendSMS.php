<?php
header("Content-type:text/html; charset=UTF-8");
/* *
 * 功能：创蓝发送信息DEMO
 * 版本：1.3
 * 日期：2017-04-12
 * 说明：
 * 以下代码只是为了方便客户测试而提供的样例代码，客户可以根据自己网站的需要，按照技术文档自行编写,并非一定要使用该代码。
 * 该代码仅供学习和研究创蓝接口使用，只是提供一个参考。
 */
//【253云通讯】为签名 用“【】”来识别签名 如果您想更换自己的签名 请前往253云通讯自助通平台报备签名或者询找您的商务负责人报备
require_once 'sendSMSAPI.php';
$clapi  = new ChuanglanSmsApi();
$code = mt_rand(100000,999999);

$result = $clapi->sendSMS('15367327820,18917407239','【253云通讯】原来你是我最想留住的幸运' ); 

if(!is_null(json_decode($result))){
	
	$output=json_decode($result,true);

	if(isset($output['code'])  && $output['code']=='0'){
		echo $result;
	}else{
		echo $output['errorMsg'];
	}
}else{
		echo $result; 
}





?>