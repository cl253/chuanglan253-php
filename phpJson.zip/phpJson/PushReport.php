<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>回送状态报告的接收</title>
</head>

<body>
	<table>
		<tr>
			<td>ID/序号</td>
			<td>msgid/批次号</td>
			<td>reportTime/运营商返回的时间</td>
			<td>mobile/手机号码</td>
			<td>notifyTime/处理的时间</td>
			<td>uid/用户ID</td>
			<td>Length/短信条数</td>
			<td>status/状态</td>
			<td>statusDesc状态说明</td>
		</tr>
	</table>
</body>
</html>