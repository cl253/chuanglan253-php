<?php
header("Content-type:text/html; charset=UTF-8");
/* *
 * 功能：创蓝发送变量短信DEMO
 * 版本：1.3
 * 日期：2018-04-17
 * 说明：
 * 以下代码只是为了方便客户测试而提供的样例代码，客户可以根据自己网站的需要，按照技术文档自行编写,并非一定要使用该代码。
 * 该代码仅供学习和研究创蓝接口使用，只是提供一个参考。
 * 
 */
 
 //【253云通讯】为签名 用“【】”来识别签名 如果您想更换自己的签名 请前往253云通讯自助通平台报备签名
require_once 'sendVariableSMSAPI.php';
$clapi  = new ChuanglanSmsApi();
$msg = '【253云通讯】{$var},您好，您发送的内容是{$var}';

$params = '15367327820,李先生,2017-04-12;15899999999,张先生，145444';

$result = $clapi->sendVariableSMS($msg, $params);

if(!is_null(json_decode($result))){
	
	$output=json_decode($result,true);

	if(isset($output['code'])  && $output['code']=='0'){
		echo $result;
	}else{
		echo $output['errorMsg'];
	}
}else{
		echo $result;
}